#!/usr/bin/env python3
"""Bounded views over complete, accounted MCP responses; no evidence is discarded."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

import client


def encode(value):
    return (json.dumps(value, ensure_ascii=True, separators=(',', ':'))+'\n').encode()


def select(value, pointer):
    """Resolve an RFC 6901 pointer without accepting ambiguous array indices."""
    if not pointer:
        return value
    if not pointer.startswith('/'):
        raise ValueError('pointer must be empty or start with /')
    for part in pointer[1:].split('/'):
        if re.search(r'~(?![01])', part):
            raise ValueError('invalid JSON pointer escape')
        part = part.replace('~1', '/').replace('~0', '~')
        if isinstance(value, dict):
            value = value[part]
        elif isinstance(value, list) and re.fullmatch(r'0|[1-9][0-9]*', part):
            value = value[int(part)]
        else:
            raise ValueError('pointer does not address an object member or array item')
    return value


def page(raw, value, pointer='', offset=0, maximum=8192, context=None):
    if not 2048 <= maximum <= 16384:
        raise ValueError('max-bytes must be between 2048 and 16384')
    value = select(value, pointer)
    # A canonical JSON string is sliced, never a raw UTF-8 byte sequence. Joining
    # data from consecutive pages reconstructs the selected JSON value exactly.
    serialized = json.dumps(value, ensure_ascii=True, separators=(',', ':'))
    if not 0 <= offset <= len(serialized):
        raise ValueError('offset outside selected value')
    base = {'view_version': 1, 'raw_sha256': hashlib.sha256(raw).hexdigest(),
            'raw_bytes': len(raw), 'pointer': pointer, 'offset': offset,
            'total_characters': len(serialized), 'encoding': 'concatenate data then JSON-decode',
            'scope': 'selected value only; other fields remain in raw response',
            'context': context or {}}

    def render(end):
        return encode(dict(base, data=serialized[offset:end],
                           next_offset=end if end < len(serialized) else None,
                           partial=offset != 0 or end != len(serialized)))

    lo, hi = offset, len(serialized)
    if len(render(lo)) > maximum:
        raise ValueError('view metadata exceeds byte cap; shorten pointer')
    while lo < hi:
        mid = (lo+hi+1)//2
        if len(render(mid)) <= maximum:
            lo = mid
        else:
            hi = mid-1
    if lo == offset and lo < len(serialized):
        raise ValueError('no room for data within byte cap')
    return render(lo)


def catalog_value(raw, tool=None):
    catalog = json.loads(raw)
    if 'result' in catalog:
        catalog = catalog['result']
    entries = catalog['tools']
    if tool is None:
        return {'view': 'tool names only; use --tool NAME for complete descriptor',
                'tools': [entry['name'] for entry in entries]}
    matches = [entry for entry in entries if entry['name'] == tool]
    if len(matches) != 1:
        raise ValueError('tool must match exactly one catalog entry')
    return matches[0]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--pointer', default='')
    parser.add_argument('--offset', type=int, default=0)
    parser.add_argument('--max-bytes', type=int, default=8192)
    sub = parser.add_subparsers(dest='command', required=True)
    cat = sub.add_parser('catalog')
    cat.add_argument('--tool')
    sub.add_parser('instructions')
    response = sub.add_parser('response')
    response.add_argument('--ordinal', type=int, required=True)
    call = sub.add_parser('call')
    call.add_argument('--name', required=True)
    call.add_argument('--arguments', required=True)
    args = parser.parse_args()
    try:
        # Validate presentation before making a charged call.
        if args.command == 'call' and (args.offset != 0 or args.pointer):
            raise ValueError('call starts at root offset zero; use response for selected views')
        page(b'', {}, '', 0, args.max_bytes)
        context = {}
        failed = False
        if args.command == 'instructions':
            raw = (args.run_dir/'initialize.json').read_bytes()
            value = json.loads(raw)['result']
            context = {'view': 'native MCP initialization; pre-assignment setup', 'charged_as_mcp_call': False}
        elif args.command == 'catalog':
            raw = (args.run_dir/'catalog.json').read_bytes()
            value = catalog_value(raw, args.tool)
            context = {'catalog_tool': args.tool, 'charged_as_mcp_call': False}
        elif args.command == 'response':
            if args.ordinal < 1:
                raise ValueError('ordinal must be positive')
            raw = (args.run_dir/f'{args.ordinal:03d}.response.raw').read_bytes()
            value = json.loads(raw)
            context = {'ordinal': args.ordinal, 'charged_as_mcp_call': False}
        else:
            raw, event = client.request(args.run_dir, 'tools/call',
                                       {'name': args.name, 'arguments': json.loads(args.arguments)})
            context = {key: event[key] for key in ('ordinal', 'calls_used', 'response_bytes_used',
                        'response_complete', 'http_status', 'error', 'stopped')}
            failed = bool(event['error'] or not event['response_complete'])
            try:
                value = json.loads(raw)
            except (ValueError, UnicodeError):
                value = {'unparsed_response': raw.decode('utf-8', errors='replace'),
                         'warning': 'invalid JSON; raw retained, decoded display may be lossy'}
        sys.stdout.buffer.write(page(raw, value, args.pointer, args.offset, args.max_bytes, context))
        return 2 if failed else 0
    except (ValueError, KeyError, IndexError, OSError, client.Stopped) as exc:
        # Keep even errors bounded; full protocol failures remain in client ledger.
        print(json.dumps({'view_error': str(exc)[:400]}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
