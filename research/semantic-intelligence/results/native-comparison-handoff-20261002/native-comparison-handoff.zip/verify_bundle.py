import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text())
for f in m['files']:
 p=(root/f['path']).resolve()
 assert p.is_relative_to(root), f['path']
 data=p.read_bytes()
 assert len(data)==f['bytes'] and hashlib.sha256(data).hexdigest()==f['sha256'], f['path']
print('Verified',len(m['files']),'packet files. Checksums establish integrity, not a trusted signature.')
